import React from "react";

function AboutUs() {
  return (
    <div
      style={{
        backgroundColor: "black",
        height: "100vh",
        width: "100vw",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <h1 style={{ color: "white" }}>About Us</h1>
    </div>
  );
}

export default AboutUs;
